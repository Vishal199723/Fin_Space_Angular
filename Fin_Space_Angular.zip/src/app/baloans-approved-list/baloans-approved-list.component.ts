import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { MessageService } from '../MessageService/meaagse.service';
import { MailService } from '../Shared/Mail/mail.service';
import { WorkflowtransService } from '../Shared/Workflow/workflowtrans.service';

@Component({
  selector: 'app-baloans-approved-list',
  templateUrl: './baloans-approved-list.component.html',
  styleUrls: ['./baloans-approved-list.component.css']
})
export class BALoansApprovedListComponent implements OnInit {
  uid: string;
  roleid: string;
  groupId: string;
  loanlist: any;

  constructor(private workflowtrnsservice: WorkflowtransService, private router: Router, private mailservice: MailService,
    private spinner: NgxSpinnerService, private messageService: MessageService,) {
      if (localStorage.getItem('IsLoggedIn') == "true") {
        this.uid = localStorage.getItem("userId");
        this.roleid = localStorage.getItem("role");
        this.groupId = localStorage.getItem("groupId");
  
      }
      this.messageService.sendSession('true');

     }

  ngOnInit() {
    this.GetBAloanapprovedlist();
  }
  GetBAloanapprovedlist() {
    this.spinner.show()
    this.workflowtrnsservice.baloanapprovedlist(this.uid).subscribe((data: any) => {
      this.loanlist = data;
      console.log(this.loanlist);
      this.spinner.hide()
    })
  }
}
