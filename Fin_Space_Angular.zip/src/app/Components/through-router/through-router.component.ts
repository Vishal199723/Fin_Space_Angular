import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { SignupService } from 'src/app/Shared/Signup/signup.service';

@Component({
  selector: 'app-through-router',
  templateUrl: './through-router.component.html',
  styleUrls: ['./through-router.component.css']
})
export class ThroughRouterComponent implements OnInit {
  BAList: any;
  selectedba: any;
  DateTime: Date;
  uid: string;
  RegisterThroughBA:any;
  constructor(private httpService: HttpClient,private router: Router,private spinner: NgxSpinnerService,private signupservice: SignupService, private datepipe: DatePipe,) { 
    this.uid = localStorage.getItem("userId");
  }

  ngOnInit() {
    this.GetAllBusinessAssociates()

  }
  RedirectUser(){
     if (localStorage.getItem('IsLoggedIn') == "true") {
        localStorage.getItem('selectedloantype');
        this.router.navigate(['/loansp']);
    }
    else{
      this.router.navigate(['/signin']);
    }
  }
  GetAllBusinessAssociates() {
    this.spinner.show()
    this.signupservice.GetAllBA().subscribe((data => {
      this.spinner.hide()
      this.BAList = data;
    }))
  }
  onSelectBA(id) {
    this.selectedba = id
  }
  SendMailToBA() {
    const frmData = new FormData();
    this.spinner.show();
    this.DateTime = new Date();
    let latest_date = this.datepipe.transform(this.DateTime, 'dd-MM-yyyy hh:mm:ss a');
    const inputRequest = {
      BAId:this.selectedba,
      UID:this.uid
    }
    frmData.append("CreatedOn", latest_date);
    frmData.append("RegData", JSON.stringify(inputRequest));
    this.spinner.show();
    this.httpService.post('https://blockchainmatrimony.com/finspaceapi/api/EnterPriseRegistration/PostSendMailToBA/', frmData).subscribe(
      data => {
        this.spinner.hide();
        alert("Selected Business Associate has be informed!")
        this.router.navigate(['/Ack']);
      });
  }
  RedirectUserToDirect(){
    this.router.navigate(['/loansp']);
  }
}
